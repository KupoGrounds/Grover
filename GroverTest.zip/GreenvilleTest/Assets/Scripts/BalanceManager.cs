﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BalanceManager : MonoBehaviour
{
    public Text balanceUI;
    public Text previousWinUI;
    public Text betUI;

    public Button playButton;

    private float balance = 10.0f;
    private float previousWinAmount = 0.0f;
    private float currentBet = 0.0f;

    public float GetBalance() { return balance; }
    public float GetPreviousWinAmount() { return previousWinAmount; }
    public float GetCurrentBet() { return currentBet; }

    public void AddToBalance(float amount)
    {
        balance += amount;

        if (balance < 0)
            balance = 0.0f;

        UpdateBalanceUI();
    }
    public void PutPreviousWinAmount(float amount)
    {
        previousWinAmount = amount;

        UpdatePreviousWinUI();
    }
    public void AddToCurrentBet(float amount)
    {
        currentBet += amount;

        if (currentBet > balance)
            currentBet = balance;

        if (currentBet < 0)
            currentBet = 0;

        if (currentBet > balance)
        {
            playButton.interactable = false;
        }
        else
        {
            playButton.interactable = true;
        }

        UpdateBetUI();
    }

    public void UpdateBalanceUI()
    {
        balanceUI.text = "Balance:\n" + balance.ToString("F2");
    }
    public void UpdatePreviousWinUI()
    {
        previousWinUI.text = "Previous Win:\n" + previousWinAmount.ToString("F2");
    }
    public void UpdateBetUI()
    {
        betUI.text = "Bet:\n" + currentBet.ToString("F2");
    }

    void Start()
    {
        UpdateBalanceUI();
        UpdatePreviousWinUI();
        UpdateBetUI();
    }
}
