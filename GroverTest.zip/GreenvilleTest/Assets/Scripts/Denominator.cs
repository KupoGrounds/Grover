﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Denominator : MonoBehaviour
{
    public BalanceManager bm;
    public float bet = 0.0f;
    
    public void AddToBet()
    {
        bm.AddToCurrentBet(bet);
    }
}
