﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class PlayManager : MonoBehaviour
{
    public Button playButton;
    public List<Button> denomButtons;
    public List<Button> chestButtons;
    public List<Text> chestTexts;
    public BalanceManager gm;

    private List<int> chestPrizes;
    private int chestIndex;
    private int currentWin = 0;

    //Being game, allowing you to click on chest prizes based on your bet and winnings
    public void BeginGame()
    {
        chestPrizes = CalculatePrizes();
        chestIndex = 0;
        currentWin = 0;
        gm.AddToBalance(-gm.GetCurrentBet());

        //Disable play button and denominators
        playButton.interactable = false;

        foreach (var denom in denomButtons)
        {
            denom.interactable = false;
        }

        //Enable chest buttons
        SetChestsInteractable(true);
    }

    //End game, switch to betting phase
    public void EndGame()
    {
        SetChestsInteractable(false);
        
        if (gm.GetCurrentBet() <= gm.GetBalance())
            playButton.interactable = true;

        foreach (var denom in denomButtons)
        {
            denom.interactable = true;
        }
    }

    //Sends the prize/pooper to whichever chest calls this function
    public void ChestPrize(Button chestButton, Text chestText)
    {
        //if the last award is the Pooper, then set chest prize as "Pooper" and end the game
        //else, set chest prize to said current award, then increment chestPrize index. Game continues.
        if (chestPrizes[chestIndex] == 0)
        {
            float win = (float)currentWin / 100;
            gm.PutPreviousWinAmount(win);
            chestText.text = "Pooper";
            EndGame();
        }
        else
        {
            currentWin += chestPrizes[chestIndex];
            float amount = chestPrizes[chestIndex];
            amount /= 100;
            gm.AddToBalance(amount);
            chestText.text = amount.ToString("F2");
            ++chestIndex;
        }
    }

    //Calculates prize multiplier for bet amount.
    private int ValidWinMultiplier()
    {
        int[] multOne = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        int[] multTwo = { 12, 16, 24, 32, 48, 64 };
        int[] multThree = { 100, 200, 300, 400, 500 };
        int num = Random.Range(1, 101);
        int result = -1;

        if (num <= 50)
        {
            result = 0;
        }
        else if (num <= 80)
        {
            result = multOne[(int)Random.Range(0, 10)];
        }
        else if (num <= 95)
        {
            result = multTwo[(int)Random.Range(0, 6)];
        }
        else
        {
            result = multThree[(int)Random.Range(0, 5)];
        }

        //Debug.Log(num + " " + result);

        return result;
    }

    //Calculates prize amount and # of chests, and splits prize equal to number of chests
    private List<int> CalculatePrizes()
    {
        List<int> result = new List<int>();
        int winAmount = (int)(gm.GetCurrentBet() * 100) * ValidWinMultiplier();
        int chestCounter;

        //while loop to ensure winAmount is divisible by 5, so that prize can be stored in chests properly
        while (true)
        {
            if (winAmount == 0)
            {
                chestCounter = 0;
                break;
            }
            else
            {
                chestCounter = Random.Range(1, 9);

                if (chestCounter <= winAmount / 5)
                    break;
            }
        }

        //if chestCounter > 1, produce n-1 random values where n is equal to the number of prize chests
        //sort random numbers from smallest to greatest
        //split prize into n pieces, using the random numbers to determine the value of each piece
        if (chestCounter == 1)
        {
            result.Add(winAmount);
        }
        else if (chestCounter > 1)
        {
            List<int> temp = new List<int>();

            while (chestCounter > 1)
            {
                int num = Random.Range(5, winAmount - 4);   //-4 is to ensure a final increment of 5 exists for the last prize chest
                int div = num / 5;
                num = div * 5;
                
                if (!temp.Contains(num))
                {
                    temp.Add(num);
                    --chestCounter;
                }
                else
                {
                    Debug.Log("Same number. Rerandoming.");
                }
            }

            //sort random values from smallest to greatest
            temp.Sort();
            
            float test = 0;

            //each piece value is the difference between the current random value and previous random value
            //first piece value is just the smallest random value
            //last piece value is the prizeAmount - largest random value
            for (int i = 0; i < temp.Count; ++i)
            {
                if (i == 0)
                {
                    result.Add(temp[i]);

                    test += temp[i];
                }
                else
                {
                    int floatArithFix = temp[i] - temp[i - 1];

                    result.Add(floatArithFix);

                    test += floatArithFix;
                }
            }

            result.Add(winAmount - temp[temp.Count - 1]);
            test += winAmount - temp[temp.Count - 1];
        }

        //Adding the Pooper chest
        result.Add(0);

        return result;
    }
    
    //Set interactivity of chest buttons
    private void SetChestsInteractable(bool status)
    {
        foreach (Button b in chestButtons)
        {
            b.interactable = status;
        }

        if (status == true)
        {
            foreach (Text t in chestTexts)
            {
                t.text = "Chest";
            }
        }
    }

    public void TweenScaleUp()
    {
        RectTransform rt = this.GetComponent<RectTransform>();
        rt.DOScale(new Vector3(1.1f, 1.1f), 0.3f);
    }

    public void TweenScaleDown()
    {
        RectTransform rt = this.GetComponent<RectTransform>();
        rt.DOScale(new Vector3(1, 1), 0.3f);
    }

    void Start()
    {
        SetChestsInteractable(false);
        playButton.interactable = true;

        foreach(Button denom in denomButtons)
        {
            denom.interactable = true;
        }
    }
}
