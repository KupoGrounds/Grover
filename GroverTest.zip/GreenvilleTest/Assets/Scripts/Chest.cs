﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Chest : MonoBehaviour
{
    public Button chestButton;
    public Text chestText;

    private Sequence sequence;

    public void Prize()
    {
        PlayManager pm = GameObject.Find("Play").GetComponent<PlayManager>();

        pm.ChestPrize(chestButton, chestText);
    }

    public void TweenScaleUp()
    {
        RectTransform rt = this.GetComponent<RectTransform>();
        rt.DOScale(new Vector3(1.1f, 1.1f), 0.3f);
    }

    public void TweenScaleDown()
    {
        RectTransform rt = this.GetComponent<RectTransform>();
        rt.DOScale(new Vector3(1, 1), 0.3f);
    }

    public void TweenRotate()
    {
        RectTransform rt = this.GetComponent<RectTransform>();
        Sequence mySequence = DOTween.Sequence();

        mySequence.Append(rt.DORotate(new Vector3(0, 0, 20), 0.75f));
        mySequence.Append(rt.DORotate(new Vector3(0, 0, -20), 0.75f));
        mySequence.Append(rt.DORotate(new Vector3(0, 0, 0), 0.5f));
        mySequence.SetEase(Ease.Linear);
        mySequence.SetLoops<Sequence>(-1, LoopType.Restart);

        sequence = mySequence;
    }

    public void TweenResetRotation()
    {
        sequence.Kill();
        RectTransform rt = this.GetComponent<RectTransform>();
        rt.DORotate(new Vector3(0, 0, 0), 0.75f);
    }
}
